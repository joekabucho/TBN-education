========
Library
========

This module was written to extend the functionality of library management to support school management and allow you to management the library through management functionality.

=============
Installation
=============

To install this module, you need to:
install 'school' module

=============
Configuration
=============

To configure this module, you need to:
have a school management functionality.

=====
Usage
=====

To use this module, you need to:

go to apps, then install module to apply this functionality.

Try me on Runbot
Known issues / Roadmap

===========
Bug Tracker
===========

Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported. If you spotted it first, help us smashing it by providing a detailed and welcomed feedback here.

========
Credits
========

Contributors
=============

Serpent Consulting Services PVT. LTD. <http://serpentcs.com>

Maintainer
==========

Serpent Consulting Services PVT. LTD.

This module is maintained by the SerpentCS.

To contribute to this module, please visit http://serpentcs.com.
