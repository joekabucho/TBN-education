# See LICENSE file for full copyright and licensing details.

{
    'name': 'Library'
    'version': '12.0.1.0.0',
    'author': 'Imprint Africa.',
    'website': 'http://www.serpentcs.com',
    'category': 'Resource Management',
    'license': "AGPL-3",
    'complexity': 'easy',
    'Summary': 'A Module For School Management',
    'images': ['static/description/EMS.jpg'],
    'depends': ['hr', 'crm', 'account'],
    'data': ['security/school_security.xml',
             'security/ir.model.access.csv',
             'wizard/terminate_reason_view.xml',
             'wizard/wiz_send_email_view.xml',
             'views/student_view.xml',
             'views/school_view.xml',
             'views/teacher_view.xml',
             'views/parent_view.xml',
             'data/student_sequence.xml',
             'wizard/assign_roll_no_wizard.xml',
             'wizard/move_standards_view.xml',
             'views/report_view.xml',
             'views/identity_card.xml',
             'views/template_view.xml'],
    'demo': ['demo/school_demo.xml'],
    'installable': True,
    'application': True
}
